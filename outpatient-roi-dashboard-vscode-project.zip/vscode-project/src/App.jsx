import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  FileText, 
  GitBranch, 
  Layers, 
  DollarSign,
  Activity,
  ChevronDown,
  ChevronRight,
  Eye,
  RefreshCw,
  AlertCircle,
  ArrowRight,
  Filter,
  Search,
  Download,
  Zap,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

// Mock data representing 837I post-bill outpatient accounts with re-bills
const mockAccounts = [
  {
    id: 'ACC-001',
    mrn: 'MRN-12345',
    accountNumber: 'BILL-67890',
    facilityId: 'FAC-001',
    facilityName: 'Memorial General Hospital',
    visitEndDate: '2025-01-15',
    patientName: 'John Smith',
    financialClass: 'Commercial - Blue Cross',
    uniqueKey: 'MRN-12345|BILL-67890|2025-01-15|FAC-001',
    serviceType: 'OUTPATIENT',
    versions: [
      {
        version: 1,
        source: '837I',
        timestamp: '2025-01-20T14:22:00Z',
        billType: '131',
        billTypeDescription: 'Hospital Outpatient - Original',
        frequencyCode: '1',
        frequencyDescription: 'Original Claim',
        claimControlNumber: 'CLM-2025-00123',
        status: 'BILLED',
        coding: {
          primaryDx: 'J18.9',
          primaryDxDesc: 'Pneumonia, unspecified organism',
          secondaryDx: [
            { code: 'E11.65', desc: 'Type 2 diabetes with hyperglycemia' },
            { code: 'I10', desc: 'Essential hypertension' },
            { code: 'Z87.891', desc: 'Personal history of nicotine dependence' }
          ],
          procedures: [
            { code: '94640', desc: 'Pressurized inhalation treatment' },
            { code: '99223', desc: 'Initial hospital care, high severity' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0250', hcpcs: '94640', units: 2, charges: 450.00, description: 'Respiratory therapy', serviceDate: '2025-01-15' },
          { revCode: '0120', hcpcs: '99223', units: 1, charges: 285.00, description: 'E/M Level 3', serviceDate: '2025-01-15' },
          { revCode: '0250', hcpcs: '94060', units: 1, charges: 175.00, description: 'Spirometry', serviceDate: '2025-01-15' },
          { revCode: '0320', hcpcs: '71046', units: 1, charges: 320.00, description: 'Chest X-Ray', serviceDate: '2025-01-15' }
        ],
        totalCharges: 1230.00,
        expectedReimbursement: 892.00,
        apcGrouping: [
          { apc: '5722', description: 'Level 2 Pulmonary Treatment', payment: 445.00 },
          { apc: '5012', description: 'Clinic Visits Level 3', payment: 447.00 }
        ]
      }
    ],
    currentVersion: 1,
    roiMetrics: {
      originalCharges: 1230.00,
      currentCharges: 1230.00,
      chargeVariance: 0,
      originalExpectedReimb: 892.00,
      currentExpectedReimb: 892.00,
      reimbVariance: 0,
      reimbVariancePercent: 0,
      rebillCount: 0,
      status: 'ORIGINAL_ONLY'
    }
  },
  {
    id: 'ACC-002',
    mrn: 'MRN-22345',
    accountNumber: 'BILL-77890',
    facilityId: 'FAC-001',
    facilityName: 'Memorial General Hospital',
    visitEndDate: '2025-01-12',
    patientName: 'Sarah Johnson',
    financialClass: 'Medicare Traditional',
    uniqueKey: 'MRN-22345|BILL-77890|2025-01-12|FAC-001',
    serviceType: 'OUTPATIENT',
    versions: [
      {
        version: 1,
        source: '837I',
        timestamp: '2025-01-14T11:45:00Z',
        billType: '131',
        billTypeDescription: 'Hospital Outpatient - Original',
        frequencyCode: '1',
        frequencyDescription: 'Original Claim',
        claimControlNumber: 'CLM-2025-00098',
        status: 'SUPERSEDED',
        coding: {
          primaryDx: 'I21.09',
          primaryDxDesc: 'STEMI involving other coronary artery',
          secondaryDx: [
            { code: 'I25.10', desc: 'Atherosclerotic heart disease' },
            { code: 'E78.5', desc: 'Hyperlipidemia' }
          ],
          procedures: [
            { code: '92920', desc: 'Percutaneous coronary intervention' },
            { code: '93458', desc: 'Left heart catheterization' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0481', hcpcs: '92920', units: 1, charges: 12500.00, description: 'PCI single vessel', serviceDate: '2025-01-12' },
          { revCode: '0481', hcpcs: '93458', units: 1, charges: 2800.00, description: 'Cath left heart', serviceDate: '2025-01-12' },
          { revCode: '0250', hcpcs: '94760', units: 3, charges: 450.00, description: 'Pulse oximetry', serviceDate: '2025-01-12' }
        ],
        totalCharges: 15750.00,
        expectedReimbursement: 18200.00,
        apcGrouping: [
          { apc: '5194', description: 'Level 4 Cardiac Procedures', payment: 18200.00 }
        ]
      },
      {
        version: 2,
        source: '837I',
        timestamp: '2025-01-22T16:30:00Z',
        billType: '137',
        billTypeDescription: 'Hospital Outpatient - Replacement',
        frequencyCode: '7',
        frequencyDescription: 'Replacement of Prior Claim',
        claimControlNumber: 'CLM-2025-00098-R1',
        originalClaimNumber: 'CLM-2025-00098',
        status: 'BILLED',
        coding: {
          primaryDx: 'I21.09',
          primaryDxDesc: 'STEMI involving other coronary artery',
          secondaryDx: [
            { code: 'I25.10', desc: 'Atherosclerotic heart disease' },
            { code: 'E78.5', desc: 'Hyperlipidemia' },
            { code: 'I10', desc: 'Essential hypertension' }  // ADDED
          ],
          procedures: [
            { code: '92920', desc: 'Percutaneous coronary intervention' },
            { code: '93458', desc: 'Left heart catheterization' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0481', hcpcs: '92920', units: 1, charges: 12500.00, description: 'PCI single vessel', serviceDate: '2025-01-12' },
          { revCode: '0481', hcpcs: '93458', units: 1, charges: 2800.00, description: 'Cath left heart', serviceDate: '2025-01-12' },
          { revCode: '0250', hcpcs: '94760', units: 3, charges: 450.00, description: 'Pulse oximetry', serviceDate: '2025-01-12' },
          { revCode: '0320', hcpcs: '71046', units: 2, charges: 640.00, description: 'Chest X-Ray', serviceDate: '2025-01-12' },  // ADDED
          { revCode: '0636', hcpcs: 'C1785', units: 2, charges: 8500.00, description: 'DES Stent', serviceDate: '2025-01-12' }  // ADDED
        ],
        totalCharges: 24890.00,
        expectedReimbursement: 26450.00,
        apcGrouping: [
          { apc: '5194', description: 'Level 4 Cardiac Procedures', payment: 18200.00 },
          { apc: '2698', description: 'Level 8 Devices', payment: 8250.00 }
        ],
        codingDelta: { 
          dxAdded: ['I10'], 
          dxRemoved: [], 
          lineItemsAdded: [
            { revCode: '0320', hcpcs: '71046', description: 'Chest X-Ray' },
            { revCode: '0636', hcpcs: 'C1785', description: 'DES Stent' }
          ],
          lineItemsRemoved: []
        }
      }
    ],
    currentVersion: 2,
    roiMetrics: {
      originalCharges: 15750.00,
      currentCharges: 24890.00,
      chargeVariance: 9140.00,
      originalExpectedReimb: 18200.00,
      currentExpectedReimb: 26450.00,
      reimbVariance: 8250.00,
      reimbVariancePercent: 45.33,
      rebillCount: 1,
      status: 'REBILLED_POSITIVE'
    }
  },
  {
    id: 'ACC-003',
    mrn: 'MRN-33456',
    accountNumber: 'BILL-88901',
    facilityId: 'FAC-002',
    facilityName: 'St. Mary Regional Medical',
    visitEndDate: '2025-01-18',
    patientName: 'Michael Davis',
    financialClass: 'Medicaid',
    uniqueKey: 'MRN-33456|BILL-88901|2025-01-18|FAC-002',
    serviceType: 'OUTPATIENT',
    versions: [
      {
        version: 1,
        source: '837I',
        timestamp: '2025-01-20T07:00:00Z',
        billType: '131',
        billTypeDescription: 'Hospital Outpatient - Original',
        frequencyCode: '1',
        frequencyDescription: 'Original Claim',
        claimControlNumber: 'CLM-2025-00156',
        status: 'ACTIVE',
        coding: {
          primaryDx: 'S72.001A',
          primaryDxDesc: 'Fracture of unsp part of neck of right femur, init',
          secondaryDx: [
            { code: 'W19.XXXA', desc: 'Unspecified fall, initial encounter' },
            { code: 'Y93.89', desc: 'Activity, other specified' }
          ],
          procedures: [
            { code: '27236', desc: 'ORIF femoral fracture' },
            { code: '77080', desc: 'DEXA bone density' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '27236', units: 1, charges: 18500.00, description: 'ORIF hip', serviceDate: '2025-01-18' },
          { revCode: '0320', hcpcs: '77080', units: 1, charges: 285.00, description: 'DEXA scan', serviceDate: '2025-01-18' },
          { revCode: '0250', hcpcs: '94760', units: 5, charges: 750.00, description: 'Pulse oximetry', serviceDate: '2025-01-18' }
        ],
        totalCharges: 19535.00,
        expectedReimbursement: 12400.00,
        apcGrouping: [
          { apc: '5116', description: 'Level 6 Musculoskeletal Procedures', payment: 12100.00 },
          { apc: '5364', description: 'Level 4 Diagnostic Tests', payment: 300.00 }
        ]
      },
      {
        version: 2,
        source: '837I',
        timestamp: '2025-01-25T10:00:00Z',
        billType: '135',
        billTypeDescription: 'Hospital Outpatient - Late Charges',
        frequencyCode: '5',
        frequencyDescription: 'Late Charges Only',
        claimControlNumber: 'CLM-2025-00156-LC',
        originalClaimNumber: 'CLM-2025-00156',
        status: 'LATE_CHARGE',
        isPartialData: true,
        coding: {
          primaryDx: 'S72.001A',
          primaryDxDesc: 'Fracture of unsp part of neck of right femur, init',
          secondaryDx: [],  // PARTIAL - only principal DX included
          procedures: [],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0420', hcpcs: '97110', units: 3, charges: 450.00, description: 'Physical therapy', serviceDate: '2025-01-18' }
        ],
        totalCharges: 450.00,
        expectedReimbursement: 185.00,
        apcGrouping: [
          { apc: '5734', description: 'Level 4 Physical Therapy', payment: 185.00 }
        ],
        codingDelta: null  // Cannot compute delta - partial data
      }
    ],
    currentVersion: 2,
    hasPartialVersion: true,
    roiMetrics: {
      originalCharges: 19535.00,
      currentCharges: 19985.00,  // Composite total
      chargeVariance: 450.00,
      originalExpectedReimb: 12400.00,
      currentExpectedReimb: 12585.00,  // Composite total
      reimbVariance: 185.00,
      reimbVariancePercent: 1.49,
      rebillCount: 1,
      lateChargeCount: 1,
      status: 'LATE_CHARGE_PENDING'
    }
  },
  {
    id: 'ACC-004',
    mrn: 'MRN-44567',
    accountNumber: 'BILL-99012',
    facilityId: 'FAC-001',
    facilityName: 'Memorial General Hospital',
    visitEndDate: '2025-01-10',
    patientName: 'Emily Rodriguez',
    financialClass: 'Commercial - Aetna',
    uniqueKey: 'MRN-44567|BILL-99012|2025-01-10|FAC-001',
    serviceType: 'OUTPATIENT',
    versions: [
      {
        version: 1,
        source: '837I',
        timestamp: '2025-01-12T09:15:00Z',
        billType: '131',
        billTypeDescription: 'Hospital Outpatient - Original',
        frequencyCode: '1',
        frequencyDescription: 'Original Claim',
        claimControlNumber: 'CLM-2025-00045',
        status: 'SUPERSEDED',
        coding: {
          primaryDx: 'K80.10',
          primaryDxDesc: 'Calculus of gallbladder with chronic cholecystitis',
          secondaryDx: [
            { code: 'E66.01', desc: 'Morbid obesity due to excess calories' },
            { code: 'K21.0', desc: 'GERD with esophagitis' }
          ],
          procedures: [
            { code: '47562', desc: 'Laparoscopic cholecystectomy' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '47562', units: 1, charges: 8500.00, description: 'Lap chole', serviceDate: '2025-01-10' },
          { revCode: '0370', hcpcs: '00790', units: 4, charges: 1200.00, description: 'Anesthesia', serviceDate: '2025-01-10' },
          { revCode: '0710', hcpcs: '99024', units: 1, charges: 0.00, description: 'Post-op visit', serviceDate: '2025-01-10' }
        ],
        totalCharges: 9700.00,
        expectedReimbursement: 6800.00,
        apcGrouping: [
          { apc: '5361', description: 'Level 1 Laparoscopy', payment: 6800.00 }
        ]
      },
      {
        version: 2,
        source: '837I',
        timestamp: '2025-01-18T14:00:00Z',
        billType: '137',
        billTypeDescription: 'Hospital Outpatient - Replacement',
        frequencyCode: '7',
        frequencyDescription: 'Replacement of Prior Claim',
        claimControlNumber: 'CLM-2025-00045-R1',
        originalClaimNumber: 'CLM-2025-00045',
        status: 'SUPERSEDED',
        coding: {
          primaryDx: 'K80.12',  // More specific
          primaryDxDesc: 'Calculus of gallbladder with acute and chronic cholecystitis',
          secondaryDx: [
            { code: 'E66.01', desc: 'Morbid obesity due to excess calories' },
            { code: 'K21.0', desc: 'GERD with esophagitis' },
            { code: 'K82.A1', desc: 'Gangrene of gallbladder' }  // ADDED - increases severity
          ],
          procedures: [
            { code: '47562', desc: 'Laparoscopic cholecystectomy' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '47562', units: 1, charges: 8500.00, description: 'Lap chole', serviceDate: '2025-01-10' },
          { revCode: '0370', hcpcs: '00790', units: 4, charges: 1200.00, description: 'Anesthesia', serviceDate: '2025-01-10' },
          { revCode: '0710', hcpcs: '99024', units: 1, charges: 0.00, description: 'Post-op visit', serviceDate: '2025-01-10' },
          { revCode: '0272', hcpcs: '96374', units: 2, charges: 340.00, description: 'IV push medication', serviceDate: '2025-01-10' }
        ],
        totalCharges: 10040.00,
        expectedReimbursement: 7250.00,
        apcGrouping: [
          { apc: '5362', description: 'Level 2 Laparoscopy', payment: 7250.00 }  // Upgraded APC
        ],
        codingDelta: { 
          dxAdded: ['K82.A1'], 
          dxRemoved: [],
          dxModified: [{ from: 'K80.10', to: 'K80.12', reason: 'Specificity upgrade' }],
          lineItemsAdded: [{ revCode: '0272', hcpcs: '96374', description: 'IV push medication' }],
          lineItemsRemoved: []
        }
      },
      {
        version: 3,
        source: '837I',
        timestamp: '2025-01-24T11:30:00Z',
        billType: '137',
        billTypeDescription: 'Hospital Outpatient - Replacement',
        frequencyCode: '7',
        frequencyDescription: 'Replacement of Prior Claim',
        claimControlNumber: 'CLM-2025-00045-R2',
        originalClaimNumber: 'CLM-2025-00045-R1',
        status: 'BILLED',
        coding: {
          primaryDx: 'K80.12',
          primaryDxDesc: 'Calculus of gallbladder with acute and chronic cholecystitis',
          secondaryDx: [
            { code: 'E66.01', desc: 'Morbid obesity due to excess calories' },
            { code: 'K21.0', desc: 'GERD with esophagitis' },
            { code: 'K82.A1', desc: 'Gangrene of gallbladder' }
          ],
          procedures: [
            { code: '47562', desc: 'Laparoscopic cholecystectomy' },
            { code: '47563', desc: 'Lap chole with cholangiography' }  // ADDED
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '47562', units: 1, charges: 8500.00, description: 'Lap chole', serviceDate: '2025-01-10' },
          { revCode: '0360', hcpcs: '47563', units: 1, charges: 1850.00, description: 'Lap chole w/ cholangiogram', serviceDate: '2025-01-10' },
          { revCode: '0370', hcpcs: '00790', units: 4, charges: 1200.00, description: 'Anesthesia', serviceDate: '2025-01-10' },
          { revCode: '0710', hcpcs: '99024', units: 1, charges: 0.00, description: 'Post-op visit', serviceDate: '2025-01-10' },
          { revCode: '0272', hcpcs: '96374', units: 2, charges: 340.00, description: 'IV push medication', serviceDate: '2025-01-10' }
        ],
        totalCharges: 11890.00,
        expectedReimbursement: 8450.00,
        apcGrouping: [
          { apc: '5363', description: 'Level 3 Laparoscopy', payment: 8450.00 }  // Further upgraded APC
        ],
        codingDelta: { 
          dxAdded: [], 
          dxRemoved: [],
          pxAdded: ['47563'],
          lineItemsAdded: [{ revCode: '0360', hcpcs: '47563', description: 'Lap chole w/ cholangiogram' }],
          lineItemsRemoved: []
        }
      }
    ],
    currentVersion: 3,
    roiMetrics: {
      originalCharges: 9700.00,
      currentCharges: 11890.00,
      chargeVariance: 2190.00,
      originalExpectedReimb: 6800.00,
      currentExpectedReimb: 8450.00,
      reimbVariance: 1650.00,
      reimbVariancePercent: 24.26,
      rebillCount: 2,
      status: 'REBILLED_POSITIVE'
    }
  },
  {
    id: 'ACC-005',
    mrn: 'MRN-55678',
    accountNumber: 'BILL-10123',
    facilityId: 'FAC-002',
    facilityName: 'St. Mary Regional Medical',
    visitEndDate: '2025-01-08',
    patientName: 'Robert Chen',
    financialClass: 'Medicare Advantage',
    uniqueKey: 'MRN-55678|BILL-10123|2025-01-08|FAC-002',
    serviceType: 'OUTPATIENT',
    versions: [
      {
        version: 1,
        source: '837I',
        timestamp: '2025-01-10T10:00:00Z',
        billType: '131',
        billTypeDescription: 'Hospital Outpatient - Original',
        frequencyCode: '1',
        frequencyDescription: 'Original Claim',
        claimControlNumber: 'CLM-2025-00032',
        status: 'SUPERSEDED',
        coding: {
          primaryDx: 'M54.5',
          primaryDxDesc: 'Low back pain',
          secondaryDx: [
            { code: 'M51.16', desc: 'Intervertebral disc degeneration, lumbar' },
            { code: 'G89.29', desc: 'Other chronic pain' }
          ],
          procedures: [
            { code: '62323', desc: 'Lumbar epidural injection' },
            { code: '77003', desc: 'Fluoroscopic guidance' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '62323', units: 1, charges: 2400.00, description: 'Epidural steroid injection', serviceDate: '2025-01-08' },
          { revCode: '0320', hcpcs: '77003', units: 1, charges: 450.00, description: 'Fluoro guidance', serviceDate: '2025-01-08' },
          { revCode: '0636', hcpcs: 'J1030', units: 2, charges: 180.00, description: 'Methylprednisolone', serviceDate: '2025-01-08' }
        ],
        totalCharges: 3030.00,
        expectedReimbursement: 1850.00,
        apcGrouping: [
          { apc: '5442', description: 'Level 2 Nerve Injections', payment: 1850.00 }
        ]
      },
      {
        version: 2,
        source: '837I',
        timestamp: '2025-01-15T15:45:00Z',
        billType: '137',
        billTypeDescription: 'Hospital Outpatient - Replacement',
        frequencyCode: '7',
        frequencyDescription: 'Replacement of Prior Claim',
        claimControlNumber: 'CLM-2025-00032-R1',
        originalClaimNumber: 'CLM-2025-00032',
        status: 'BILLED',
        coding: {
          primaryDx: 'M54.5',
          primaryDxDesc: 'Low back pain',
          secondaryDx: [
            { code: 'M51.16', desc: 'Intervertebral disc degeneration, lumbar' }
            // Removed G89.29 - incorrect per documentation
          ],
          procedures: [
            { code: '62323', desc: 'Lumbar epidural injection' },
            { code: '77003', desc: 'Fluoroscopic guidance' }
          ],
          hcpcsModifiers: []
        },
        lineItems: [
          { revCode: '0360', hcpcs: '62323', units: 1, charges: 2400.00, description: 'Epidural steroid injection', serviceDate: '2025-01-08' },
          { revCode: '0320', hcpcs: '77003', units: 1, charges: 450.00, description: 'Fluoro guidance', serviceDate: '2025-01-08' },
          { revCode: '0636', hcpcs: 'J1030', units: 1, charges: 90.00, description: 'Methylprednisolone', serviceDate: '2025-01-08' }  // Corrected units
        ],
        totalCharges: 2940.00,
        expectedReimbursement: 1780.00,
        apcGrouping: [
          { apc: '5442', description: 'Level 2 Nerve Injections', payment: 1780.00 }
        ],
        codingDelta: { 
          dxAdded: [], 
          dxRemoved: ['G89.29'],
          lineItemsAdded: [],
          lineItemsRemoved: [],
          lineItemsModified: [{ revCode: '0636', hcpcs: 'J1030', change: 'Units: 2 → 1' }]
        }
      }
    ],
    currentVersion: 2,
    roiMetrics: {
      originalCharges: 3030.00,
      currentCharges: 2940.00,
      chargeVariance: -90.00,
      originalExpectedReimb: 1850.00,
      currentExpectedReimb: 1780.00,
      reimbVariance: -70.00,
      reimbVariancePercent: -3.78,
      rebillCount: 1,
      status: 'REBILLED_NEGATIVE'
    }
  }
];

// Frequency code reference for outpatient 837I
const frequencyCodeMap = {
  '1': { label: 'Original Claim', color: 'emerald', bgColor: 'bg-emerald-100', textColor: 'text-emerald-700', description: 'Complete original claim submission' },
  '5': { label: 'Late Charges', color: 'amber', bgColor: 'bg-amber-100', textColor: 'text-amber-700', description: 'Late charges only - PARTIAL DATA', warning: true },
  '7': { label: 'Replacement', color: 'purple', bgColor: 'bg-purple-100', textColor: 'text-purple-700', description: 'Complete replacement of prior claim' },
  '8': { label: 'Void/Cancel', color: 'red', bgColor: 'bg-red-100', textColor: 'text-red-700', description: 'Void/cancel prior claim entirely' }
};

// Outpatient bill types (13X series)
const outpatientBillTypes = {
  '131': 'Hospital Outpatient - Original',
  '132': 'Hospital Outpatient - Interim First',
  '133': 'Hospital Outpatient - Interim Continuing',
  '134': 'Hospital Outpatient - Interim Last',
  '135': 'Hospital Outpatient - Late Charges',
  '137': 'Hospital Outpatient - Replacement',
  '138': 'Hospital Outpatient - Void/Cancel'
};

// Component for displaying coding differences
function CodingDiffBadge({ delta, type, label }) {
  if (!delta) return null;
  const items = delta[type] || [];
  if (items.length === 0) return null;

  const colors = {
    Added: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    Removed: 'bg-red-100 text-red-800 border-red-200',
    Modified: 'bg-amber-100 text-amber-800 border-amber-200'
  };

  return (
    <div className="mt-2">
      <span className="text-xs font-medium text-slate-500 uppercase">{label}</span>
      <div className="flex flex-wrap gap-1 mt-1">
        {items.map((item, i) => (
          <span key={i} className={`text-xs px-2 py-0.5 rounded-full border ${colors[label] || colors.Modified}`}>
            {typeof item === 'string' ? item : item.code || item.hcpcs || item.change || item.description}
          </span>
        ))}
      </div>
    </div>
  );
}

// Version timeline component for post-bill 837I
function VersionTimeline({ versions, onSelectVersion, selectedVersion }) {
  return (
    <div className="relative">
      {/* Connecting line */}
      <div className="absolute left-4 top-8 bottom-8 w-0.5 bg-gradient-to-b from-indigo-300 via-indigo-400 to-indigo-300" />
      
      {versions.map((version, idx) => {
        const isSelected = selectedVersion === version.version;
        const freqInfo = frequencyCodeMap[version.frequencyCode] || {};
        const isOriginal = version.frequencyCode === '1';
        const isRebill = version.frequencyCode === '7';
        const isLateCharge = version.frequencyCode === '5';
        
        return (
          <div key={version.version} className="relative flex items-start gap-4 mb-4 last:mb-0">
            {/* Timeline dot */}
            <div 
              className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-all duration-200 ${
                isSelected 
                  ? 'bg-indigo-600 text-white ring-4 ring-indigo-200' 
                  : isOriginal
                    ? 'bg-emerald-100 text-emerald-700 border-2 border-emerald-400 hover:border-emerald-500'
                    : isLateCharge
                      ? 'bg-amber-100 text-amber-700 border-2 border-amber-400 hover:border-amber-500'
                      : isRebill
                        ? 'bg-purple-100 text-purple-700 border-2 border-purple-400 hover:border-purple-500'
                        : 'bg-white text-slate-600 border-2 border-slate-300 hover:border-indigo-400'
              }`}
              onClick={() => onSelectVersion(version.version)}
            >
              <span className="text-xs font-bold">{version.version}</span>
            </div>
            
            {/* Version card */}
            <div 
              className={`flex-1 p-3 rounded-lg cursor-pointer transition-all duration-200 ${
                isSelected 
                  ? 'bg-indigo-50 border-2 border-indigo-300 shadow-md' 
                  : 'bg-white border border-slate-200 hover:border-indigo-200 hover:shadow-sm'
              }`}
              onClick={() => onSelectVersion(version.version)}
            >
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded ${freqInfo.bgColor} ${freqInfo.textColor}`}>
                    {version.frequencyCode}: {freqInfo.label}
                  </span>
                  {version.isPartialData && (
                    <span className="text-xs font-medium px-2 py-0.5 rounded bg-red-100 text-red-700 border border-red-300 flex items-center gap-1">
                      <AlertTriangle size={10} /> Partial
                    </span>
                  )}
                  {version.status === 'SUPERSEDED' && (
                    <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                      Superseded
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-500">
                  {new Date(version.timestamp).toLocaleDateString()} {new Date(version.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              
              <p className="text-xs text-slate-500 mb-1">
                Bill Type: {version.billType} · Claim #: {version.claimControlNumber}
              </p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="text-sm text-slate-700">
                    <span className="font-medium">{version.lineItems.length}</span> lines · 
                    <span className="font-medium"> ${version.totalCharges.toLocaleString()}</span>
                  </span>
                  <span className="text-sm text-emerald-700">
                    Est: <span className="font-medium">${version.expectedReimbursement.toLocaleString()}</span>
                  </span>
                </div>
                {version.codingDelta && (
                  <span className="text-xs text-indigo-600 flex items-center gap-1">
                    <GitBranch size={12} /> Changes
                  </span>
                )}
              </div>

              {/* Show coding deltas */}
              {version.codingDelta && (
                <div className="mt-2 pt-2 border-t border-slate-100">
                  <CodingDiffBadge delta={version.codingDelta} type="dxAdded" label="Added" />
                  <CodingDiffBadge delta={version.codingDelta} type="dxRemoved" label="Removed" />
                  <CodingDiffBadge delta={version.codingDelta} type="lineItemsAdded" label="Added" />
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Composite View for accounts with late charges
function CompositeAccountView({ account }) {
  const composite = useMemo(() => {
    const originalVersion = account.versions.find(v => v.frequencyCode === '1');
    const latestCompleteVersion = [...account.versions]
      .reverse()
      .find(v => !v.isPartialData && v.status !== 'SUPERSEDED');
    const lateChargeVersions = account.versions.filter(v => v.frequencyCode === '5');
    
    // Use coding from latest complete version (or original if no complete rebill)
    let mergedCoding = latestCompleteVersion?.coding || originalVersion?.coding;
    
    // Merge all line items
    const allLineItems = new Map();
    
    // Start with the latest complete version's line items
    const baseVersion = latestCompleteVersion || originalVersion;
    if (baseVersion) {
      baseVersion.lineItems.forEach(item => {
        const key = `${item.revCode}-${item.hcpcs}-${item.serviceDate}`;
        allLineItems.set(key, { ...item, fromVersion: baseVersion.version, isLateCharge: false });
      });
    }
    
    // Append late charge line items
    lateChargeVersions.forEach(v => {
      v.lineItems.forEach(item => {
        const key = `${item.revCode}-${item.hcpcs}-${item.serviceDate}-LC${v.version}`;
        allLineItems.set(key, { ...item, fromVersion: v.version, isLateCharge: true });
      });
    });
    
    const lineItemsArray = Array.from(allLineItems.values());
    
    return {
      coding: mergedCoding,
      lineItems: lineItemsArray,
      totalCharges: lineItemsArray.reduce((sum, item) => sum + item.charges, 0),
      totalExpectedReimb: account.versions
        .filter(v => v.status !== 'SUPERSEDED')
        .reduce((sum, v) => sum + v.expectedReimbursement, 0) - 
        (account.versions.filter(v => v.frequencyCode !== '1' && v.frequencyCode !== '5' && v.status !== 'SUPERSEDED')
          .slice(0, -1)
          .reduce((sum, v) => sum + v.expectedReimbursement, 0)),
      hasLateCharges: lateChargeVersions.length > 0,
      lateChargeCount: lateChargeVersions.length
    };
  }, [account]);

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Layers className="text-indigo-600" size={20} />
          <h4 className="font-semibold text-slate-800">Composite Account View</h4>
        </div>
        <span className="text-xs bg-indigo-600 text-white px-2 py-1 rounded-full">
          {account.versions.length} submissions merged
        </span>
      </div>
      
      {composite.hasLateCharges && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
          <div className="flex items-center gap-2 text-amber-800">
            <AlertCircle size={16} />
            <span className="text-sm font-medium">
              {composite.lateChargeCount} late charge submission(s) merged
            </span>
          </div>
          <p className="text-xs text-amber-700 mt-1">
            Late charges (freq code 5) contain partial data. This view combines all submissions 
            to show the complete billable account.
          </p>
        </div>
      )}
      
      {/* Merged line items */}
      <div className="bg-white rounded-lg p-3 border border-slate-200">
        <h5 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Complete Line Items</h5>
        <div className="max-h-48 overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 sticky top-0">
              <tr>
                <th className="text-left p-2 text-slate-600 font-medium">Rev</th>
                <th className="text-left p-2 text-slate-600 font-medium">HCPCS</th>
                <th className="text-left p-2 text-slate-600 font-medium">Description</th>
                <th className="text-right p-2 text-slate-600 font-medium">Charges</th>
                <th className="text-center p-2 text-slate-600 font-medium">Source</th>
              </tr>
            </thead>
            <tbody>
              {composite.lineItems.map((item, idx) => (
                <tr key={idx} className={`border-t border-slate-100 ${item.isLateCharge ? 'bg-amber-50' : ''}`}>
                  <td className="p-2 font-mono text-xs">{item.revCode}</td>
                  <td className="p-2 font-mono text-xs">{item.hcpcs}</td>
                  <td className="p-2 text-xs text-slate-600">{item.description}</td>
                  <td className="p-2 text-right font-medium">${item.charges.toLocaleString()}</td>
                  <td className="p-2 text-center">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      item.isLateCharge ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {item.isLateCharge ? 'Late' : `v${item.fromVersion}`}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-3 pt-3 border-t border-slate-200 flex justify-between items-center">
          <span className="text-slate-600 font-medium">Composite Total:</span>
          <span className="text-xl font-bold text-indigo-700">${composite.totalCharges.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}

// ROI Metrics Card - Post-Bill Focus
function ROIMetricsCard({ account }) {
  const { roiMetrics } = account;
  const originalVersion = account.versions.find(v => v.frequencyCode === '1');
  const currentVersion = account.versions[account.versions.length - 1];
  
  const varianceColor = roiMetrics.reimbVariance > 0 
    ? 'text-emerald-600' 
    : roiMetrics.reimbVariance < 0 
      ? 'text-red-600' 
      : 'text-slate-600';
  
  const VarianceIcon = roiMetrics.reimbVariance > 0 ? TrendingUp : roiMetrics.reimbVariance < 0 ? TrendingDown : Activity;
  
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold text-slate-800 flex items-center gap-2">
          <BarChart3 className="text-indigo-600" size={18} />
          Post-Bill ROI Analysis
        </h4>
        <div className="flex items-center gap-2">
          {roiMetrics.rebillCount > 0 && (
            <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
              {roiMetrics.rebillCount} Re-bill{roiMetrics.rebillCount > 1 ? 's' : ''}
            </span>
          )}
          {roiMetrics.lateChargeCount > 0 && (
            <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full">
              {roiMetrics.lateChargeCount} Late Charge{roiMetrics.lateChargeCount > 1 ? 's' : ''}
            </span>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-xs text-slate-500 uppercase tracking-wide">Original 837I</p>
          <p className="text-lg font-bold text-slate-800">
            ${roiMetrics.originalExpectedReimb?.toLocaleString() || '—'}
          </p>
          <p className="text-xs text-slate-500">
            Charges: ${roiMetrics.originalCharges?.toLocaleString()}
          </p>
        </div>
        
        <div className="bg-slate-50 rounded-lg p-3">
          <p className="text-xs text-slate-500 uppercase tracking-wide">Current Expected</p>
          <p className="text-lg font-bold text-slate-800">
            ${roiMetrics.currentExpectedReimb?.toLocaleString() || '—'}
          </p>
          <p className="text-xs text-slate-500">
            Charges: ${roiMetrics.currentCharges?.toLocaleString()}
          </p>
        </div>
      </div>
      
      {roiMetrics.reimbVariance !== 0 && (
        <div className={`rounded-lg p-3 ${
          roiMetrics.reimbVariance > 0 ? 'bg-emerald-50' : 'bg-red-50'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <VarianceIcon size={18} className={varianceColor} />
              <span className="text-sm text-slate-600">Re-bill Impact</span>
            </div>
            <div className="text-right">
              <span className={`text-lg font-bold ${varianceColor}`}>
                {roiMetrics.reimbVariance >= 0 ? '+' : ''}${roiMetrics.reimbVariance.toLocaleString()}
              </span>
              <span className={`text-sm ml-2 ${varianceColor}`}>
                ({roiMetrics.reimbVariancePercent >= 0 ? '+' : ''}{roiMetrics.reimbVariancePercent.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>
      )}
      
      {/* APC Groupings */}
      {currentVersion?.apcGrouping && (
        <div className="mt-4 pt-4 border-t border-slate-200">
          <h5 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
            Current APC Assignment
          </h5>
          <div className="space-y-2">
            {currentVersion.apcGrouping.map((apc, idx) => (
              <div key={idx} className="flex items-center justify-between bg-slate-50 rounded p-2">
                <div>
                  <span className="text-xs font-mono text-indigo-600">{apc.apc}</span>
                  <span className="text-xs text-slate-600 ml-2">{apc.description}</span>
                </div>
                <span className="text-sm font-medium text-slate-700">${apc.payment.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Account Detail Panel
function AccountDetailPanel({ account, onClose }) {
  const [selectedVersion, setSelectedVersion] = useState(account.currentVersion);
  const currentVersionData = account.versions.find(v => v.version === selectedVersion);
  
  return (
    <div className="fixed inset-y-0 right-0 w-[720px] bg-white shadow-2xl border-l border-slate-200 z-50 overflow-hidden flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-700 to-indigo-600 text-white p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-bold">{account.patientName}</h3>
          <button 
            onClick={onClose}
            className="text-indigo-200 hover:text-white transition-colors text-xl"
          >
            ✕
          </button>
        </div>
        <div className="flex items-center gap-4 text-sm text-indigo-200">
          <span>MRN: {account.mrn}</span>
          <span>•</span>
          <span>Acct: {account.accountNumber}</span>
          <span>•</span>
          <span>DOS: {account.visitEndDate}</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <span className="text-xs bg-indigo-500/50 px-2 py-1 rounded">
            {account.facilityName}
          </span>
          <span className="text-xs bg-indigo-500/50 px-2 py-1 rounded">
            {account.financialClass}
          </span>
          <span className="text-xs bg-emerald-500/80 px-2 py-1 rounded font-medium">
            OUTPATIENT
          </span>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* ROI Metrics */}
        <ROIMetricsCard account={account} />
        
        {/* Version Timeline */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <h4 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <GitBranch className="text-indigo-600" size={18} />
            837I Submission History
          </h4>
          <VersionTimeline 
            versions={account.versions} 
            onSelectVersion={setSelectedVersion}
            selectedVersion={selectedVersion}
          />
        </div>
        
        {/* Composite View (for accounts with late charges) */}
        {account.hasPartialVersion && (
          <CompositeAccountView account={account} />
        )}
        
        {/* Selected Version Detail */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-slate-800 flex items-center gap-2">
              <Eye className="text-indigo-600" size={18} />
              Version {selectedVersion} Detail
            </h4>
            <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded font-mono">
              {currentVersionData?.claimControlNumber}
            </span>
          </div>
          
          {/* Coding */}
          {currentVersionData?.coding && (
            <div className="mb-4">
              <h5 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Diagnosis Codes</h5>
              <div className="space-y-1">
                <div className="flex items-start gap-2">
                  <span className="bg-indigo-100 text-indigo-800 px-2 py-1 rounded text-sm font-mono">
                    {currentVersionData.coding.primaryDx}
                  </span>
                  <span className="text-sm text-slate-600 pt-0.5">{currentVersionData.coding.primaryDxDesc}</span>
                </div>
                {currentVersionData.coding.secondaryDx.map((dx, i) => (
                  <div key={i} className="flex items-start gap-2">
                    <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded text-sm font-mono">
                      {dx.code}
                    </span>
                    <span className="text-sm text-slate-500 pt-0.5">{dx.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {currentVersionData?.isPartialData && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-4">
              <div className="flex items-center gap-2 text-amber-800">
                <AlertTriangle size={16} />
                <span className="text-sm font-medium">Partial Data - Late Charges Only</span>
              </div>
              <p className="text-xs text-amber-700 mt-1">
                This submission contains only late charge line items. Secondary diagnoses and 
                procedures from the original claim are not repeated.
              </p>
            </div>
          )}
          
          {/* Line Items */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="text-left p-2 text-slate-600 font-medium">Rev</th>
                  <th className="text-left p-2 text-slate-600 font-medium">HCPCS</th>
                  <th className="text-left p-2 text-slate-600 font-medium">Description</th>
                  <th className="text-center p-2 text-slate-600 font-medium">Units</th>
                  <th className="text-right p-2 text-slate-600 font-medium">Charges</th>
                </tr>
              </thead>
              <tbody>
                {currentVersionData?.lineItems.map((item, idx) => (
                  <tr key={idx} className="border-t border-slate-100">
                    <td className="p-2 font-mono text-xs">{item.revCode}</td>
                    <td className="p-2 font-mono text-xs">{item.hcpcs}</td>
                    <td className="p-2 text-xs text-slate-600">{item.description}</td>
                    <td className="p-2 text-center">{item.units}</td>
                    <td className="p-2 text-right font-medium">${item.charges.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-50 font-medium">
                <tr>
                  <td colSpan="4" className="p-2 text-right">Total Charges:</td>
                  <td className="p-2 text-right">${currentVersionData?.totalCharges.toLocaleString()}</td>
                </tr>
                <tr className="text-emerald-700">
                  <td colSpan="4" className="p-2 text-right">Expected Reimbursement:</td>
                  <td className="p-2 text-right">${currentVersionData?.expectedReimbursement.toLocaleString()}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// Summary Cards - Post-Bill Focus
function SummaryCards({ accounts }) {
  const stats = useMemo(() => {
    const total = accounts.length;
    const rebilled = accounts.filter(a => a.roiMetrics.rebillCount > 0);
    const positiveROI = rebilled.filter(a => a.roiMetrics.reimbVariance > 0);
    const negativeROI = rebilled.filter(a => a.roiMetrics.reimbVariance < 0);
    const lateCharges = accounts.filter(a => a.hasPartialVersion);
    
    const totalOriginalReimb = accounts.reduce((sum, a) => sum + (a.roiMetrics.originalExpectedReimb || 0), 0);
    const totalCurrentReimb = accounts.reduce((sum, a) => sum + (a.roiMetrics.currentExpectedReimb || 0), 0);
    const netVariance = totalCurrentReimb - totalOriginalReimb;
    
    const totalPositiveVariance = positiveROI.reduce((sum, a) => sum + a.roiMetrics.reimbVariance, 0);
    const totalNegativeVariance = negativeROI.reduce((sum, a) => sum + Math.abs(a.roiMetrics.reimbVariance), 0);
    
    return {
      total,
      rebilledCount: rebilled.length,
      positiveCount: positiveROI.length,
      negativeCount: negativeROI.length,
      lateChargeCount: lateCharges.length,
      totalOriginalReimb,
      totalCurrentReimb,
      netVariance,
      totalPositiveVariance,
      totalNegativeVariance
    };
  }, [accounts]);
  
  return (
    <div className="grid grid-cols-6 gap-4 mb-6">
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <FileText className="text-slate-400" size={20} />
          <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">Total</span>
        </div>
        <p className="text-3xl font-bold text-slate-800 mt-2">{stats.total}</p>
        <p className="text-sm text-slate-500">837I Accounts</p>
      </div>
      
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <RefreshCw className="text-purple-500" size={20} />
          <span className="text-xs bg-purple-100 text-purple-600 px-2 py-0.5 rounded-full">Re-bills</span>
        </div>
        <p className="text-3xl font-bold text-purple-600 mt-2">{stats.rebilledCount}</p>
        <p className="text-sm text-slate-500">With Re-bills</p>
      </div>
      
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <ArrowUpRight className="text-emerald-500" size={20} />
          <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded-full">↑ ROI</span>
        </div>
        <p className="text-3xl font-bold text-emerald-600 mt-2">{stats.positiveCount}</p>
        <p className="text-sm text-slate-500">Positive Impact</p>
      </div>
      
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <ArrowDownRight className="text-red-500" size={20} />
          <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">↓ ROI</span>
        </div>
        <p className="text-3xl font-bold text-red-600 mt-2">{stats.negativeCount}</p>
        <p className="text-sm text-slate-500">Negative Impact</p>
      </div>
      
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <Clock className="text-amber-500" size={20} />
          <span className="text-xs bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full">Late</span>
        </div>
        <p className="text-3xl font-bold text-amber-600 mt-2">{stats.lateChargeCount}</p>
        <p className="text-sm text-slate-500">Late Charges</p>
      </div>
      
      <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-4 shadow-sm text-white">
        <div className="flex items-center justify-between">
          <DollarSign className="text-white/70" size={20} />
          <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">Net</span>
        </div>
        <p className="text-2xl font-bold mt-2">
          {stats.netVariance >= 0 ? '+' : ''}${stats.netVariance.toLocaleString()}
        </p>
        <p className="text-sm text-white/80">Re-bill Impact</p>
      </div>
    </div>
  );
}

// Main Dashboard Component
export default function OutpatientPostBillROIDashboard() {
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  const filteredAccounts = useMemo(() => {
    return mockAccounts.filter(account => {
      const matchesSearch = 
        account.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        account.mrn.toLowerCase().includes(searchTerm.toLowerCase()) ||
        account.accountNumber.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesFilter = 
        filterStatus === 'all' ||
        (filterStatus === 'rebilled' && account.roiMetrics.rebillCount > 0) ||
        (filterStatus === 'positive' && account.roiMetrics.reimbVariance > 0) ||
        (filterStatus === 'negative' && account.roiMetrics.reimbVariance < 0) ||
        (filterStatus === 'late' && account.hasPartialVersion) ||
        (filterStatus === 'original' && account.roiMetrics.rebillCount === 0);
      
      return matchesSearch && matchesFilter;
    });
  }, [searchTerm, filterStatus]);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-[1800px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
                  Outpatient Post-Bill ROI Dashboard
                </h1>
                <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full font-medium">
                  837I Only
                </span>
              </div>
              <p className="text-sm text-slate-500 mt-1">
                Track re-bill impact and late charge ROI for outpatient 837I claims
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors text-sm font-medium">
                <Download size={16} />
                Export
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium">
                <RefreshCw size={16} />
                Sync 837I
              </button>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="max-w-[1800px] mx-auto px-6 py-6">
        {/* Summary Cards */}
        <SummaryCards accounts={mockAccounts} />
        
        {/* Filters & Search */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 mb-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                type="text"
                placeholder="Search by patient, MRN, or account..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Filter size={16} className="text-slate-400" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm bg-white"
              >
                <option value="all">All Accounts</option>
                <option value="rebilled">Re-billed Accounts</option>
                <option value="positive">Positive ROI</option>
                <option value="negative">Negative ROI</option>
                <option value="late">With Late Charges</option>
                <option value="original">Original Only</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* 837I Frequency Code Reference */}
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-4 mb-6">
          <h3 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
            <FileText className="text-indigo-600" size={18} />
            Outpatient 837I Bill Types (13X Series)
          </h3>
          <div className="flex flex-wrap gap-3">
            {Object.entries(outpatientBillTypes).map(([code, description]) => {
              const freqCode = code[2];
              const freqInfo = frequencyCodeMap[freqCode] || {};
              return (
                <div 
                  key={code}
                  className={`bg-white rounded-lg px-3 py-2 border shadow-sm ${
                    freqInfo.warning ? 'border-amber-300' : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-bold px-2 py-0.5 rounded ${freqInfo.bgColor || 'bg-slate-100'} ${freqInfo.textColor || 'text-slate-700'}`}>
                      {code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{description}</p>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Accounts Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left p-4 text-slate-600 font-semibold text-sm">Patient / Account</th>
                <th className="text-left p-4 text-slate-600 font-semibold text-sm">Facility</th>
                <th className="text-center p-4 text-slate-600 font-semibold text-sm">Submissions</th>
                <th className="text-center p-4 text-slate-600 font-semibold text-sm">Latest Type</th>
                <th className="text-right p-4 text-slate-600 font-semibold text-sm">Original Est.</th>
                <th className="text-right p-4 text-slate-600 font-semibold text-sm">Current Est.</th>
                <th className="text-right p-4 text-slate-600 font-semibold text-sm">ROI Impact</th>
                <th className="text-center p-4 text-slate-600 font-semibold text-sm">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredAccounts.map((account) => {
                const latestVersion = account.versions[account.versions.length - 1];
                const freqInfo = frequencyCodeMap[latestVersion.frequencyCode] || {};
                
                return (
                  <tr 
                    key={account.id}
                    className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer transition-colors"
                    onClick={() => setSelectedAccount(account)}
                  >
                    <td className="p-4">
                      <div className="font-medium text-slate-800">{account.patientName}</div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        MRN: {account.mrn} · Acct: {account.accountNumber}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-slate-600">{account.facilityName}</span>
                      <div className="text-xs text-slate-400">{account.visitEndDate}</div>
                    </td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {account.versions.map((v, i) => {
                          const vFreq = frequencyCodeMap[v.frequencyCode] || {};
                          return (
                            <span 
                              key={i}
                              className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${vFreq.bgColor || 'bg-slate-100'} ${vFreq.textColor || 'text-slate-700'} ${v.status === 'SUPERSEDED' ? 'opacity-50' : ''}`}
                              title={`v${v.version}: ${vFreq.label || 'Unknown'}`}
                            >
                              {v.version}
                            </span>
                          );
                        })}
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      <span className={`text-xs font-medium px-2 py-1 rounded ${freqInfo.bgColor || 'bg-slate-100'} ${freqInfo.textColor || 'text-slate-700'}`}>
                        {latestVersion.billType}
                      </span>
                    </td>
                    <td className="p-4 text-right font-medium text-slate-700">
                      ${account.roiMetrics.originalExpectedReimb?.toLocaleString() || '—'}
                    </td>
                    <td className="p-4 text-right font-medium text-slate-700">
                      ${account.roiMetrics.currentExpectedReimb?.toLocaleString() || '—'}
                    </td>
                    <td className="p-4 text-right">
                      {account.roiMetrics.reimbVariance !== 0 ? (
                        <span className={`font-bold ${
                          account.roiMetrics.reimbVariance > 0 
                            ? 'text-emerald-600' 
                            : 'text-red-600'
                        }`}>
                          {account.roiMetrics.reimbVariance >= 0 ? '+' : ''}
                          ${account.roiMetrics.reimbVariance.toLocaleString()}
                          <span className="text-xs ml-1">
                            ({account.roiMetrics.reimbVariancePercent >= 0 ? '+' : ''}
                            {account.roiMetrics.reimbVariancePercent.toFixed(1)}%)
                          </span>
                        </span>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                    <td className="p-4 text-center">
                      {account.roiMetrics.status === 'REBILLED_POSITIVE' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-emerald-100 text-emerald-700">
                          <TrendingUp size={12} />
                          Re-billed ↑
                        </span>
                      )}
                      {account.roiMetrics.status === 'REBILLED_NEGATIVE' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-red-100 text-red-700">
                          <TrendingDown size={12} />
                          Re-billed ↓
                        </span>
                      )}
                      {account.roiMetrics.status === 'LATE_CHARGE_PENDING' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-amber-100 text-amber-700">
                          <Clock size={12} />
                          Late Charge
                        </span>
                      )}
                      {account.roiMetrics.status === 'ORIGINAL_ONLY' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded bg-slate-100 text-slate-600">
                          <CheckCircle size={12} />
                          Original
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {/* Solution Notes */}
        <div className="mt-8 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-200 p-6">
          <h3 className="font-bold text-slate-800 text-lg mb-4">
            💡 Post-Bill 837I ROI Tracking: Key Concepts
          </h3>
          
          <div className="grid grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-slate-700 mb-2">What We're Tracking</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-indigo-500 mt-0.5">●</span>
                  <span><strong>Original 837I (131):</strong> First outpatient claim submission with initial expected reimbursement</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-500 mt-0.5">●</span>
                  <span><strong>Replacement 837I (137):</strong> Complete re-bill that supersedes prior claim - ROI impact calculated</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-amber-500 mt-0.5">●</span>
                  <span><strong>Late Charges (135):</strong> Additional charges added post-billing - merged into composite view</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-slate-700 mb-2">ROI Calculation</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-500 mt-0.5">✓</span>
                  <span><strong>Positive ROI:</strong> Re-bill resulted in higher expected reimbursement (coding improvement, missed charges captured)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-red-500 mt-0.5">✓</span>
                  <span><strong>Negative ROI:</strong> Re-bill resulted in lower expected reimbursement (coding corrections, charge adjustments)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-slate-500 mt-0.5">✓</span>
                  <span><strong>Late Charge Impact:</strong> Additional reimbursement from charges added after original billing</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-white rounded-lg border border-slate-200">
            <h4 className="font-semibold text-slate-700 mb-2">Outpatient Bill Type Structure (13X)</h4>
            <div className="grid grid-cols-4 gap-4 text-sm">
              <div className="bg-emerald-50 rounded p-2 border border-emerald-200">
                <span className="font-bold text-emerald-700">131</span>
                <p className="text-emerald-600 text-xs mt-1">Original complete outpatient claim</p>
              </div>
              <div className="bg-amber-50 rounded p-2 border border-amber-200">
                <span className="font-bold text-amber-700">135</span>
                <p className="text-amber-600 text-xs mt-1">Late charges only (partial data)</p>
              </div>
              <div className="bg-purple-50 rounded p-2 border border-purple-200">
                <span className="font-bold text-purple-700">137</span>
                <p className="text-purple-600 text-xs mt-1">Complete replacement of prior claim</p>
              </div>
              <div className="bg-red-50 rounded p-2 border border-red-200">
                <span className="font-bold text-red-700">138</span>
                <p className="text-red-600 text-xs mt-1">Void/cancel prior claim</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Detail Panel */}
      {selectedAccount && (
        <>
          <div 
            className="fixed inset-0 bg-black/30 z-40"
            onClick={() => setSelectedAccount(null)}
          />
          <AccountDetailPanel 
            account={selectedAccount} 
            onClose={() => setSelectedAccount(null)} 
          />
        </>
      )}
    </div>
  );
}
