# Outpatient Post-Bill ROI Dashboard

A React dashboard for tracking ROI from outpatient 837I post-bill and re-bill files.

## Quick Setup

### Prerequisites
- Node.js 16+ installed
- npm or yarn

### Installation

1. **Extract this folder** to your desired location

2. **Open terminal in the project folder** and run:
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open in browser:**
   Navigate to http://localhost:5173

That's it! You should see the dashboard running with full Tailwind CSS styling.

## Project Structure

```
outpatient-postbill-roi-dashboard/
├── index.html          # Entry HTML file
├── package.json        # Dependencies and scripts
├── vite.config.js      # Vite bundler config
├── tailwind.config.js  # Tailwind CSS config
├── postcss.config.js   # PostCSS config
└── src/
    ├── main.jsx        # React entry point
    ├── index.css       # Tailwind imports
    └── App.jsx         # Main dashboard component
```

## VS Code Extensions (Recommended)

For the best development experience, install these VS Code extensions:

1. **ES7+ React/Redux/React-Native snippets** - React code snippets
2. **Tailwind CSS IntelliSense** - Tailwind autocomplete
3. **Prettier** - Code formatting
4. **ESLint** - Code linting

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## Technologies Used

- React 18
- Vite (build tool)
- Tailwind CSS (styling)
- Lucide React (icons)
